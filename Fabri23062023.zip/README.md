SELECT usuarios.nome, produtos.descricao FROM usuarios, produtos WHERE usuarios.id ='3' AND produtos.id ='24'
