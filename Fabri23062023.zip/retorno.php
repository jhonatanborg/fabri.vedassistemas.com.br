<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
	<title>Erro</title>
	<!--CSS BOOTSTRAP -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>
<!--INICIO CONTAINER-->
<div class="container">
 <center>
<!--INICIO ROW-->
  <div class="row">
  <!--INICIO GRID-->
    <div class="col-MD-12">
    <div class="jumbotron">
     <h1>Olá,</h1>
     <p>Desculpe,você não pode acessar este local.</p>
     <p>Login ou Senha invalidos ou não tem autorização para acessar esse setor!</p>
     <p>Por favor entrar em contato com ADMINISTRADOR.</p>
     <p><a  href="index.php" class="btn btn-primary btn-lg">VOLTAR</a></p>
  <!--FINAL GRID-->
   </div>
<!--FINAL ROW-->
  </div> 
<!--FINAL CONTAINER-->
</div>
 </center>
<!--JS BOOTSTRAP-->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!--JS JQUERY-->
	<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
</body>
</html>